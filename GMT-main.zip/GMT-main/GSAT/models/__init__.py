from .gin import GIN
from .sgc import SGC
from .spmotif_gnn import SPMotifNet
from .pna import PNA
