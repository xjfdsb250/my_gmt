from .gen_spmotif import gen_dataset
