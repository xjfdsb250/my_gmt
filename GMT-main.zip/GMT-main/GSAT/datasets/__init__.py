from .ba_2motifs import SynGraphDataset
from .mutag import Mutag
from .spmotif import SPMotif
from .mnist import MNIST75sp
